# -*- coding: utf-8 -*-
# author:yejunyao
# datetime:2023/4/30 20:27

"""
description：
"""
import os
import random
import shutil

from concurrent.futures import ThreadPoolExecutor, as_completed
import time
from pycparser import c_parser
from get_transform import transform_1, transform_2, transform_3, transform_4, transform_5, transform_6, transform_7, \
    transform_8, transform_9, transform_10, transform_11, transform_12, transform_13, transform_14, transform_15, \
    transform_16, transform_17, transform_18, transform_19, transform_20, transform_21, transform_22, transform_23
from utils.get_style import program_to_xml
from utils.tools import check_syntax
from utils import get_style
parser = c_parser.CParser()




def change_style(file_root, file_name, selected_list):
    path_program = os.path.join(file_root, file_name)
    program_name = path_program.split('/')[-1].split('.')[0]
    #  1.复制domain_root原始数据集到aug_program_save_path，复制到domain_root中的文件夹结构不变
    relative_path_d = os.path.relpath(file_root, domain_root)
    aug_program_save_dir = os.path.join(aug_program_save_path, relative_path_d)
    os.makedirs(aug_program_save_dir, exist_ok=True)
    shutil.copy2(path_program, aug_program_save_dir)
    xml_save_dir = os.path.join(xml_save_path, relative_path_d)
    os.makedirs(xml_save_dir, exist_ok=True)
    converted_styles = []
    for change_index in selected_list:
        # 2.将aug_program_save_path数据集转换为xml保存到xml_save_path
        get_style.srcml_program_xml(os.path.join(aug_program_save_dir, file),
                                    os.path.join(xml_save_dir, program_name))
        program_style = get_style.get_style(os.path.join(xml_save_dir, program_name) + '.xml')

        eval('transform_' + str(change_index)).transform_random(program_style[change_index], program_name,
                                                                xml_save_dir, converted_styles)
        if str(change_index) not in converted_styles:# 如果此风格转换失败，则不替换原来的code
            continue
        #
        code_changed_program = os.path.join(code_changed_path, relative_path_d, program_name + '.c')
        os.makedirs(os.path.join(code_changed_path, relative_path_d), exist_ok=True)
        get_style.srcml_xml_program(os.path.join(xml_save_dir, program_name) + '.xml',
                                    code_changed_program)
        # 4.验证code_changed_path中代码的正确性，如果正确，替换aug_program_save_path中的代码，如果失败，不替换。
        if check_syntax(code_changed_program, parser):
            # 如果正确，替换aug_program_save_path中的代码
            shutil.move(code_changed_program, os.path.join(aug_program_save_dir, file))
        else:
            converted_styles.remove(str(change_index))
            print('style failed', change_index)
            print(code_changed_program)
    return converted_styles







def process_file(root, file):
    path_program = os.path.join(root, file)
    program_name = path_program.split('/')[-1].split('.')[0]
    root_dir = os.path.dirname(path_program)
    #  1.复制domain_root原始数据集到aug_program_save_path，复制到domain_root中的文件夹结构不变
    relative_path = os.path.relpath(root_dir, domain_root)
    aug_program_save_dir = os.path.join(aug_program_save_path, relative_path)
    os.makedirs(aug_program_save_dir, exist_ok=True)
    shutil.copy2(path_program, aug_program_save_dir)
    xml_save_dir = os.path.join(xml_save_path, relative_path)
    os.makedirs(xml_save_dir, exist_ok=True)
    converted_styles = []
    for change_index in [20, 21, 22]:
        # 2.将aug_program_save_path数据集转换为xml保存到xml_save_path
        get_style.srcml_program_xml(os.path.join(aug_program_save_dir, file),
                                    os.path.join(xml_save_dir, program_name))

        program_style = get_style.get_style(os.path.join(xml_save_dir, program_name) + '.xml')
        # 3.变换风格，更新xml，转回程序，保存到code_changed_path
        eval('transform_' + str(change_index)).transform_random(program_style[change_index], program_name,
                                                                xml_save_dir, converted_styles)
        if str(change_index) not in converted_styles:
            continue
        code_changed_program = os.path.join(code_changed_path, relative_path, program_name + '.c')
        os.makedirs(os.path.join(code_changed_path, relative_path), exist_ok=True)
        get_style.srcml_xml_program(os.path.join(xml_save_dir, program_name) + '.xml',
                                    code_changed_program)
        # 4.验证code_changed_path中代码的正确性，如果正确，替换aug_program_save_path中的代码，如果失败，不替换。
        if check_syntax(code_changed_program, parser):
            shutil.move(code_changed_program, os.path.join(aug_program_save_dir, file))
        else:
            converted_styles.remove(str(change_index))
            print('style failed:', change_index)








if __name__ == '__main__':
    """
        code_changed,如果此风格转换成功，则替换原来的code，否则不替换。
        风格转换成功指符合语法正确性。
        domain_root:原始数据集路径
        aug_program_save_path:转换成功后的程序保存路径
        code_changed_path:未确认成功的程序保存路径
        xml_save_path:转换后的程序xml保存路径
    """

    """
        1.复制原始数据集到aug_program_save_path
        2.将aug_program_save_path数据集转换为xml保存到xml_save_path
        3.变换风格，更新xml，转回程序，保存到code_changed_path
        4.验证code_changed_path中代码的正确性，如果正确，替换aug_program_save_path中的代码，如果失败，不替换。
        5.进行下一个风格转换，重复2-4步骤。
        6.如何程序顺利完成转换，最终保存到to_dataset中。
    """
    """
        1.基于statement数据集，生成all_changed_test数据集
        具备的变化有
        [20, 21, 22]-block
        需要把随机生成词级扰动的代码加进来-设置为变化24
        还有变化5加进来
    """
    """
        all_changed:  24, 
        5,6,7, 8, 9,10, 18, 19 ,
        20, 21, 22,
        
    """

    from_dataset = 'origin_s'
    to_dataset = 'mix_s'
    data_root = '/home/yjy/code/2023/paper01_data/code_function/data1/'
    domain_root = data_root + from_dataset + '/'
    os.makedirs(os.path.join(data_root, to_dataset), exist_ok=True)

    aug_program_save_path = data_root+'by-product/aug_program_save_path/' + to_dataset + '/'
    xml_save_path = data_root+'by-product/style/' + to_dataset + '/'
    code_changed_path = data_root+'by-product/code_changed/' + to_dataset + '/'
    os.makedirs(aug_program_save_path, exist_ok=True)
    os.makedirs(xml_save_path, exist_ok=True)
    os.makedirs(code_changed_path, exist_ok=True)

    # 生成xml，保存到xml_save_path，xml是scrml工具生成的，xml格式便于修改
    program_to_xml(domain_root, xml_save_path)

    change_index_list = [5,6,7, 8, 9,10, 18, 19,20, 21, 22]  # 10, 12, 18，6, 7, 8, 9, 18, 19   # [20, 21, 22] block


    for root, sub_dirs, files in os.walk(domain_root):
        for file in files:
            # 获取origin的相对路径
            # relative_path = os.path.relpath(root, os.path.join(data_root, to_dataset))
            # 复制对应路径下的origin程序到os.path.join(root1, file1)
            # shutil.copy(os.path.join(root1, file1), os.path.join(aug_program_save_path, relative_path, file1))
            s_list = []
            for i in range(3):
                n = random.randint(1, len(change_index_list))
                s_list = random.sample(change_index_list, n)
                result = change_style(root, file, s_list)
                if result:
                    break
            change_style(root, file,change_index_list)


    # 如何程序顺利完成转换，最终保存到to_dataset中。
    if not os.path.exists(os.path.join(data_root, to_dataset)):
        # 复制文件夹
        shutil.copytree(aug_program_save_path, os.path.join(data_root, to_dataset))
